﻿namespace silva_adriano_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SAVoitureAmphibie sAVoitureAmphibie = new SAVoitureAmphibie();


        }
    }
}