﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace silva_adriano_3
{
    internal interface ISAVehiculeTerrestre : ISAVehicule
    {
        public void SARouler();
    }
}
